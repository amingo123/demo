﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Services
{
    public interface IAccountService{ }

    public interface IMessageService
    {
        public string Text { get; set; }
    }
    public interface IToolService{ }

    public class AccountService: IAccountService {}
    public class MessageService: IMessageService
    {
        public string Text { get; set; }

        public MessageService()
        {
            Text = "Hello Message";
        }
    }
    public class ToolService: IToolService{}
}
