﻿using System;
using System.Diagnostics;
using Microsoft.Extensions.DependencyInjection;

namespace ConsoleApp1
{
    
    class Program
    {
        static void Main(string[] args)
        {
           Sample06.Run();

        }
    }
}
