﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Autofac;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1
{
    public class ControllerModule : Autofac.Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            var containerBaseType = typeof(ControllerBase);
            
            builder.RegisterAssemblyTypes(Assembly.GetExecutingAssembly())
                .Where(t=>containerBaseType.IsAssignableFrom(t) && t!=containerBaseType)
                .PropertiesAutowired();
        }
    }
}
