﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;

namespace ConsoleApp2
{
    public static class Sample01
    {
        public interface IAccount{ }
        public interface IMessage{ }
        public interface ITool{ }

        public class Base
        {
            public Base()
            {
                Console.WriteLine($"Created:{GetType().Name}");
            }

        }

        public class Account:Base, IAccount{}
        public class Message:Base, IMessage{}
        public class Tool:Base, ITool{}

        public static void Run()
        {
            var serviceCollection = new ServiceCollection()
                .AddTransient<IAccount, Account>()
                .AddTransient<IMessage, Message>();

            var containerBuilder = new ContainerBuilder();

            containerBuilder.Populate(serviceCollection);

            containerBuilder.RegisterType<Tool>().As<ITool>();

            var container = containerBuilder.Build();

            IServiceProvider provider = new AutofacServiceProvider(container);
        }
    }
}
