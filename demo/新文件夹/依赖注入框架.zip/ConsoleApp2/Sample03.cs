﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.DependencyInjection;

namespace ConsoleApp2
{
    public static class Sample03
    {
        public interface IAccount{ }
        public interface ITool{ }

        public interface IMessageService { }

        public class EmailMessageService : IMessageService
        {
            public IAccount Account { get; set; }
            public ITool Tool { get; set; }

            public EmailMessageService(IAccount account, ITool tool)
            {
                Account = account;
                Tool = tool;
            }

            public void Test()
            {
                Console.WriteLine(Account.GetHashCode());
                Console.WriteLine(Tool.GetHashCode());
            }
        }

        public class SmsMessageService : IMessageService
        {
            public IServiceProvider ServiceProvider { get; set; }

            public SmsMessageService(IServiceProvider serviceProvider)
            {
                ServiceProvider = serviceProvider;
            }

            public void Test()
            {
                Console.WriteLine(ServiceProvider.GetService<IAccount>().GetHashCode());
                Console.WriteLine(ServiceProvider.GetService<ITool>().GetHashCode());
            }
        }

    }
}
