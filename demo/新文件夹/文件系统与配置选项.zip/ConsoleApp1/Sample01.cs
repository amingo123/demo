﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;

namespace ConsoleApp1
{
    public static class Sample01
    {
        public static void Run()
        {
            var provider = new ServiceCollection()
                .AddSingleton<IFileProvider>(new PhysicalFileProvider(@"e:\其它"))
                .AddSingleton<FileManager>()
                .BuildServiceProvider();
            var fileManager = provider.GetService<FileManager>();
            fileManager.Dir();
        }

        public class FileManager
        {
            private readonly IFileProvider _fileProvider;
            public FileManager(IFileProvider fileProvider)
            {
                _fileProvider = fileProvider;
            }

            public void Dir()
            {
                var indent = -1;

                void Get(string subpath)
                {
                    indent++;
                    foreach (var fileinfo in _fileProvider.GetDirectoryContents(subpath))
                    {
                        Console.WriteLine(new string('\t',indent) + fileinfo.Name);
                        if (fileinfo.IsDirectory)
                        {
                            Get($@"{subpath}\{fileinfo.Name}");
                        }
                    }
                    
                }

                Get("");
                
            }
        }
    }
}
