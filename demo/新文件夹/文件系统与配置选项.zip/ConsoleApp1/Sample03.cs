﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Primitives;

namespace ConsoleApp1
{
    public static class Sample03
    {
        public static void Run()
        {
            var provider = new ServiceCollection()
                .AddSingleton<IFileProvider>(new PhysicalFileProvider(@"e:\其它"))
                .AddSingleton<FileManager>()
                .BuildServiceProvider();
            var fileManager = provider.GetService<FileManager>();
            fileManager.WatchAsync("Text.txt").Wait();
            Console.Read();
        }

        public class FileManager
        {
            private readonly IFileProvider _fileProvider;
            public FileManager(IFileProvider fileProvider)
            {
                _fileProvider = fileProvider;
            }

            public async Task WatchAsync(string path)
            {
                Console.WriteLine(await ReadAsync(path));

                ChangeToken.OnChange(() => _fileProvider.Watch(path), async () =>
                {
                    Console.Clear();
                    Console.WriteLine(await ReadAsync(path));
                });
            }

            public async Task<string> ReadAsync(string path)
            {
                await using var stream = _fileProvider.GetFileInfo(path).CreateReadStream();
                var buffer = new byte[stream.Length];
                await stream.ReadAsync(buffer, 0, buffer.Length);
                return Encoding.Default.GetString(buffer);
            }
        }
    }
}
