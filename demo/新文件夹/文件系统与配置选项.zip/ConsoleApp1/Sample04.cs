﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.FileProviders;

namespace ConsoleApp1
{
    public static class Sample04
    {
        public class FileManager
        {
            public FileManager(IFileProvider fileProvider)
            {
                // 路径不包含前缀 "/"
                {
                    var contents = fileProvider.GetDirectoryContents("tests");
                    var fileinfo = fileProvider.GetFileInfo("tests/test.txt");
                    var changeToken = fileProvider.Watch("tests/*.txt");
                }

                // 路径包含前缀 "/"
                {
                    var contents = fileProvider.GetDirectoryContents("/tests");
                    var fileinfo = fileProvider.GetFileInfo("/tests/test.txt");
                    var changeToken = fileProvider.Watch("/tests/*.txt");
                }
            }


        }
    }
}
