﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration.Memory;

namespace ConsoleApp2
{
    public static class Sample02
    {
        public class AppConfigDemo
        {
            public string Name  { get; set; }
            public string StartDate { get; set; }
            public string EndDate { get; set; }
        }

        public static void Run()
        {
            var source = new Dictionary<string, string>
            {
                ["Name"] = "AppConfig",
                ["StartDate"] = "2020年5月1日",
                ["EndDate"] = "2020年5月5日"
            };

            var options = new ConfigurationBuilder()
                .AddInMemoryCollection(source)
                .Build()
                .Get<AppConfigDemo>();

            Console.WriteLine($"Name:{options.Name}");
            Console.WriteLine($"StartDate:{options.StartDate}");
            Console.WriteLine($"EndDate:{options.EndDate}");
        }
    }
}