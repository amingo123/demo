﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration.Memory;

namespace ConsoleApp2
{
    public static class Sample01
    {
        public class AppConfigDemo
        {
            public string Name  { get; set; }
            public string StartDate { get; set; }
            public string EndDate { get; set; }

            public AppConfigDemo(IConfiguration config)
            {
                Name = config["Name"];
                StartDate = config["StartDate"];
                EndDate = config["EndDate"];
            }
        }

        public static void Run()
        {
            var source = new Dictionary<string, string>
            {
                ["Name"] = "AppConfig",
                ["StartDate"] = "2020年5月1日",
                ["EndDate"] = "2020年5月5日"
            };

            var config = new ConfigurationBuilder()
                .Add(new MemoryConfigurationSource{InitialData = source})
                .Build();

            var options = new AppConfigDemo(config);
            Console.WriteLine($"Name:{options.Name}");
            Console.WriteLine($"StartDate:{options.StartDate}");
            Console.WriteLine($"EndDate:{options.EndDate}");
        }
    }
}
