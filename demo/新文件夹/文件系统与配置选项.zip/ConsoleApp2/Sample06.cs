﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp2
{
    public static class Sample06
    {
        public class AppConfigDemo
        {
            public string Name  { get; set; }
            public string Version { get; set; }
        }

        public static void Run(string[] args)
        {
            var mapping = new Dictionary<string, string>()
            {
                ["-n"] = "Name",
                ["-ver"] = "Version"
            };

            var config = new ConfigurationBuilder()
                .AddCommandLine(args, mapping)
                .Build()
                .Get<AppConfigDemo>();

            Console.WriteLine($"Name:{config.Name}");
            Console.WriteLine($"Ver:{config.Version}");
        }
    }
}
