﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration.Json;
using Microsoft.Extensions.Configuration.Memory;
using Microsoft.Extensions.Primitives;

namespace ConsoleApp2
{
    public static class Sample04
    {
        public class AppConfigDemo
        {
            public string Name  { get; set; }
            public string StartDate { get; set; }
            public string EndDate { get; set; }

            public Behavior Behavior { get; set; }
        }

        public class Behavior
        {
            public bool IsRead { get; set; }
            public bool IsWrite { get; set; }
        }

        public static void Run()
        {
            var config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", true, true)
                .Build();
            
            Read(config.Get<AppConfigDemo>());
            ChangeToken.OnChange(() => config.GetReloadToken(), () =>
            {
                Read(config.Get<AppConfigDemo>());
            });
            Console.Read();
        }

        public static void Read(AppConfigDemo options)
        {
            Console.Clear();
            Console.WriteLine($"Name:{options.Name}");
            Console.WriteLine($"StartDate:{options.StartDate}");
            Console.WriteLine($"EndDate:{options.EndDate}");
            Console.WriteLine($"Behavior.IsRead:{options.Behavior.IsRead}");
            Console.WriteLine($"Behavior.IsWrite:{options.Behavior.IsWrite}");
        }
    }
}