﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace ConsoleApp2
{
    public static class Sample05
    {
        public class AppConfigDemo
        {
            public string Name  { get; set; }
            public string Ver { get; set; }
        }


        public static void Run()
        {
            Environment.SetEnvironmentVariable("APP_NAME", "AppDemo");
            Environment.SetEnvironmentVariable("APP_VER", "Alpha");

            var config = new ConfigurationBuilder()
                .AddEnvironmentVariables("APP_")
                .Build()
                .Get<AppConfigDemo>();

            Console.WriteLine($"Name:{config.Name}");
            Console.WriteLine($"Ver:{config.Ver}");
        }
    }
}
