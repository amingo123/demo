﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace ConsoleApp3
{
    public static class Sample06
    {
        public class AppConfigDemo
        {
            public string Name  { get; set; }
            public string Version { get; set; }
        }

        public static void Run(string[] args)
        {
            var mapping = new Dictionary<string, string>()
            {
                ["-n"] = "Name",
                ["-ver"] = "Version"
            };

            var config = new ConfigurationBuilder()
                .AddCommandLine(args, mapping)
                .Build();

            var services = new ServiceCollection();
            services.AddOptions<AppConfigDemo>()
                .Configure(options =>
                {
                    options.Name = config["Name"] ?? "";
                    options.Version = config["Version"] ?? "";
                })
                .Validate(demo => demo.Version.StartsWith("Alpha"), "Version 参数无效")
                .Validate(demo => demo.Name.EndsWith("App"), "Name 参数无效");

            try
            {
                var options = services.BuildServiceProvider()
                    .GetRequiredService<IOptions<AppConfigDemo>>().Value;
                Console.WriteLine(options.Name);
                Console.WriteLine(options.Version);
            }
            catch (OptionsValidationException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


    }
}
