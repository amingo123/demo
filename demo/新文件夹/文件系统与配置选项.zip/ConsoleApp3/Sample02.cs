﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace ConsoleApp3
{
    public static class Sample02
    {
        public class AppConfigDemo
        {
            public string Name  { get; set; }
            public string StartDate { get; set; }
            public string EndDate { get; set; }
        }


        public static void Run()
        {
            var configuration = new ConfigurationBuilder()
                .AddJsonFile("muti.json")
                .Build();

            var serviceProvider = new ServiceCollection()
                .AddOptions()
                .Configure<AppConfigDemo>("DefaultApp", configuration.GetSection("DefaultApp"))
                .Configure<AppConfigDemo>("CustomApp", configuration.GetSection("CustomApp"))
                .BuildServiceProvider();

            var options = serviceProvider.GetRequiredService<IOptionsSnapshot<AppConfigDemo>>();

            var defaultApp = options.Get("DefaultApp");
            var customApp = options.Get("CustomApp");

            Console.WriteLine($"Name:{defaultApp.Name}");
            Console.WriteLine($"StartDate:{defaultApp.StartDate}");
            Console.WriteLine($"EndDate:{defaultApp.EndDate}");


            Console.WriteLine($"Name:{customApp.Name}");
            Console.WriteLine($"StartDate:{customApp.StartDate}");
            Console.WriteLine($"EndDate:{customApp.EndDate}");
        }
    }
}