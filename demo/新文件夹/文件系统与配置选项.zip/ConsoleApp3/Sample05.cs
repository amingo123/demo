﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace ConsoleApp3
{
    public static class Sample05
    {
        public class AppConfigDemo
        {
            public string Name  { get; set; }
            public string StartDate { get; set; }
            public string EndDate { get; set; }
        }

        public static void Run()
        {
            var serviceProvider = new ServiceCollection()
                .AddOptions()
                .Configure<AppConfigDemo>(config =>
                {
                    config.Name = "DefaultApp";
                    config.StartDate = "2020/5/6";
                    config.EndDate = "2020/5/7";
                })
                .BuildServiceProvider();

            var options = serviceProvider.GetRequiredService<IOptions<AppConfigDemo>>();
            var appConfig = options.Value;

            Console.WriteLine($"Name:{appConfig.Name}");
            Console.WriteLine($"StartDate:{appConfig.StartDate}");
            Console.WriteLine($"EndDate:{appConfig.EndDate}");
        }
    }
}
