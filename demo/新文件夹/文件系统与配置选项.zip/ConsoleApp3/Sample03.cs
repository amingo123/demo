﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace ConsoleApp3
{
    public static class Sample03
    {
        public class AppConfigDemo
        {
            public string Name  { get; set; }
            public string StartDate { get; set; }
            public string EndDate { get; set; }

            public Behavior Behavior { get; set; }
        }

        public class Behavior
        {
            public bool IsRead { get; set; }
            public bool IsWrite { get; set; }
        }

        public static void Run()
        {
            var configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", false, true)
                .Build();

            var serviceProvider = new ServiceCollection()
                .AddOptions()
                .Configure<AppConfigDemo>(configuration)
                .BuildServiceProvider();

            var options = serviceProvider.GetRequiredService<IOptionsMonitor<AppConfigDemo>>();

            options.OnChange(appConfig =>
            {
                Console.Clear();
                Console.WriteLine($"Name:{appConfig.Name}");
                Console.WriteLine($"StartDate:{appConfig.StartDate}");
                Console.WriteLine($"EndDate:{appConfig.EndDate}");
                Console.WriteLine($"Behavior.IsRead:{appConfig.Behavior.IsRead}");
                Console.WriteLine($"Behavior.IsWrite:{appConfig.Behavior.IsWrite}");
            });

            Console.Read();

        }
    }
}
